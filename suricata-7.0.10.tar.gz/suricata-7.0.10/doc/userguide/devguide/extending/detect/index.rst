Detection
=========
