Suricata Socket Control
=======================

SYNOPSIS
--------

**suricatasc**

DESCRIPTION
-----------

Suricata socket control tool

COMMANDS
---------

.. include:: ../partials/commands-sc.rst

PCAP MODE COMMANDS
-------------------

.. include:: ../partials/commands-pcap-sc.rst


BUGS
----

Please visit Suricata's support page for information about submitting
bugs or feature requests.

NOTES
-----

* Suricata Home Page

    https://suricata.io/

* Suricata Support Page

    https://suricata.io/support/
